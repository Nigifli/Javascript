const express = require('express');
const app = express();
const PORT = 3000;

app.use(express.json());

let cars = [
    { id: 1, brand: 'Toyota', model: 'Corolla', year: 2020 },
    { id: 2, brand: 'Ford', model: 'Focus', year: 2018 }
];

app.get('/cars', (req, res) => {
    res.json(cars);
});

app.get('/cars/:id', (req, res) => {
    const car = cars.find(c => c.id === parseInt(req.params.id));
    if (!car) return res.status(404).json({ message: 'Autó nem található' });
    res.json(car);
});

app.post('/cars', (req, res) => {
    const { brand, model, year } = req.body;
    const newCar = { id: cars.length + 1, brand, model, year };
    cars.push(newCar);
    res.status(201).json(newCar);
});

app.put('/cars/:id', (req, res) => {
    const car = cars.find(c => c.id === parseInt(req.params.id));
    if (!car) return res.status(404).json({ message: 'Autó nem található' });
    
    const { brand, model, year } = req.body;
    car.brand = brand || car.brand;
    car.model = model || car.model;
    car.year = year || car.year;
    res.json(car);
});

app.delete('/cars/:id', (req, res) => {
    const carIndex = cars.findIndex(c => c.id === parseInt(req.params.id));
    if (carIndex === -1) return res.status(404).json({ message: 'Autó nem található' });
    
    const deletedCar = cars.splice(carIndex, 1);
    res.json(deletedCar[0]);
});

app.listen(PORT, () => {
    console.log(`Szerver fut a http://localhost:${PORT} címen`);
});