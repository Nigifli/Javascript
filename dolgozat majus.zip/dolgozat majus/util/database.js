import Database from "better-sqlite3";

const db = new Database('./data/database.sqlite');

db.prepare('CREATE TABLE IF NOT EXISTS books (id INTEGER PRIMARY KEY AUTOINCREMENT, title string, author string)').run()

export const getBooks = () => db
.prepare('SELECT * FROM books').all()

export const getBook = (id) => db
.prepare('SELECT * FROM books WHERE id = ?').get(id)

export const saveBook = (title, author) => db
.prepare('INSERT INTO books (title, author) VALUES (?, ?)').run(title, author)

export const deleteBook = () => db
.prepare('DELETE FROM books WHERE id = ?').run(id)

const books = [
    {title: "Egy Konyv", author: "William Shakespeare"},
    {title: "Meg egy Konyv", author: "JK Rowling"},
    {title: "Utolsoelotti Konyv", author: "Jane Austin"},
    {title: "Utolso Konyv", author: "Klebelsberg Kuno"}
]

// for (const book of books) saveBook(book.title, book.author);