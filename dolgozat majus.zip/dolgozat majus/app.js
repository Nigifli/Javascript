import express from 'express';
import * as db from './util/database.js'

const PORT = 8080
const app = express()
app.use(express.json())

app.get('/books', (req, res) => {
    try {
    const books = db.getBooks()
    res.status(200).json(books)
    }
    catch (err) {
        res.status(404).json({message: $`${err}`})
    }
})

app.get('/books/:id', (req, res) => {
    try {
        const book = db.getBook(req.params.id)
        if(!book) {
            return res.status(404).json({message: `The book couldn't be found.`})
        }
        res.status(200).json(book)
    }
    catch (err) {
        res.status(500).json({message: $`${err}`})
    }
    
})

app.post('/books', (req, res) => {
    try {
        const {title, author} = req.body
        if(!title || !author) {
            return res.status(400).json({message: `The book is invalid.`})
        }
        const savedBook = db.saveBook(title, author)

        if (savedBook.changes != 1) {
            return res.status(501).json({message: `The save of the book lead to fail.`})
        }
    }
    catch (err) {
        res.status(500).json({message: $`${err}`})
    }
})

app.delete('/books/:id', (req, res) => {
    try {
        const deleteBook = db.deleteBook(req.params.id)
        if(savedBook.changes != 1) {
            return res.status(404).json({message: `The delete of the book lead to fail.`})
        }
    
        res.status(204).json()
    }
    
    catch {
        res.status(500).json({message: $`${err}`})
    }
})

app.listen(PORT, () => {
    console.log(`The server is running on port ${PORT}`)
})