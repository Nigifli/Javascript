const baseUrl = 'http://localhost:3000';
const albumsContainer = document.getElementById('albums-container');
const addAlbumBtn = document.getElementById('add-album-btn');
const albumDialog = document.getElementById('album-dialog');
const albumForm = document.getElementById('album-form');
const dialogTitle = document.getElementById('dialog-title');
const cancelBtn = document.getElementById('cancel-btn');
const searchBar = document.getElementById('search-bar');

let albums = [];
let editAlbumId = null;

async function fetchAlbums() {
    const response = await fetch(`${baseUrl}/albums`);
    albums = await response.json();
    renderAlbums();
}

function renderAlbums(filteredAlbums = albums) {
    albumsContainer.innerHTML = '';
    filteredAlbums.forEach(album => {
        const albumCard = document.createElement('div');
        albumCard.classList.add('album-card');
        albumCard.innerHTML = `
            <h3>${album.title}</h3>
            <p><strong>Szerző:</strong> ${album.artist}</p>
            <p><strong>Album hossza:</strong> ${album.duration}</p>
            <p><strong>Zenék száma:</strong> ${album.trackCount}</p>
            <button class="edit-btn" data-id="${album.id}">Szerkesztés</button>
            <button class="delete-btn" data-id="${album.id}">Törlés</button>
        `;
        albumsContainer.appendChild(albumCard);
    });

    document.querySelectorAll('.edit-btn').forEach(button => {
        button.addEventListener('click', handleEditAlbum);
    });
    document.querySelectorAll('.delete-btn').forEach(button => {
        button.addEventListener('click', handleDeleteAlbum);
    });
}

function handleAddAlbum() {
    editAlbumId = null;
    dialogTitle.textContent = 'Album hozzáadása';
    albumForm.reset();
    albumDialog.classList.remove('hidden');
}

function handleEditAlbum(event) {
    const id = event.target.dataset.id;
    const album = albums.find(album => album.id == id);
    if (!album) {
        return;
    }
    editAlbumId = id;
    dialogTitle.textContent = 'Album szerkesztése';
    albumForm.artist.value = album.artist;
    albumForm.title.value = album.title;
    albumForm.duration.value = album.duration;
    albumForm.trackCount.value = album.trackCount;
    albumDialog.classList.remove('hidden');
}

async function handleDeleteAlbum(event) {
    const id = event.target.dataset.id;
    await fetch(`${baseUrl}/album/${id}`, { method: 'DELETE' });
    fetchAlbums();
}

function handleSearch(event) {
    const query = event.target.value.toLowerCase();
    const filteredAlbums = albums.filter(album => album.title.toLowerCase().includes(query));
    renderAlbums(filteredAlbums);
}

albumForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    const albumData = {
        artist: albumForm.artist.value,
        title: albumForm.title.value,
        duration: albumForm.duration.value,
        trackCount: albumForm.trackCount.value
    };

    if (editAlbumId) {
        await fetch(`${baseUrl}/album/${editAlbumId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(albumData)
        });
    } else {
        await fetch(`${baseUrl}/album`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(albumData)
        });
    }

    albumDialog.classList.add('hidden');
    fetchAlbums();
});

cancelBtn.addEventListener('click', () => {
    albumDialog.classList.add('hidden');
});

addAlbumBtn.addEventListener('click', handleAddAlbum);
fetchAlbums();

searchBar.addEventListener('input', handleSearch);

searchBar.addEventListener('input', handleSearch);