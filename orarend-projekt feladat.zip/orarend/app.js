const express = require("express");
const cors = require("cors");
const app = express();
const port = 3001;

app.use(cors());
app.use(express.json());

let timetable = [];

app.get("/api/timetable", (req, res) => {
  res.json(timetable);
});

app.post("/api/timetable", (req, res) => {
  const { subject, day, hour } = req.body;
  if (!subject || !day || hour == null) {
    return res.status(400).json({ error: "Hiányzó adat" });
  }
  timetable.push({ id: Date.now(), subject, day, hour });
  res.status(201).json({ message: "Az óra hozzá lett adva" });
});

app.delete("/api/timetable/:id", (req, res) => {
  const id = parseInt(req.params.id);
  timetable = timetable.filter(item => item.id !== id);
  res.json({ message: "Az óra törölve lett" });
});

app.put("/api/timetable/:id", (req, res) => {
  const id = parseInt(req.params.id);
  const { subject, day, hour } = req.body;
  const index = timetable.findIndex(item => item.id === id);
  if (index === -1) return res.status(404).json({ error: "Nem található" });

  timetable[index] = { ...timetable[index], subject, day, hour };
  res.json({ message: "Az óra sikeresen módosítva" });
});

app.listen(port, () => {
  console.log(`API fut a http://localhost:${port} szerveren`);
});