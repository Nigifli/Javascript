const apiEndpoint = 'http://localhost:3000';
const container = document.getElementById('container');
const newAlbumBtn = document.getElementById('new-album-btn');
const albumModal = document.getElementById('album-modal');
const albumFormElement = document.getElementById('album-form-element');
const modalTitle = document.getElementById('modal-title');
const closeModalBtn = document.getElementById('cancel-btn');
const searchInput = document.getElementById('search-input');

let albumList = [];
let currentAlbumId = null;

async function loadAlbums() {
    try {
        const response = await fetch(`${apiEndpoint}/albums`);
        if (!response.ok) throw new Error('Network response was not ok');
        albumList = await response.json();
        console.log('Albums fetched:', albumList); 
        displayAlbums();
    } catch (error) {
        console.error('Error fetching albums:', error);
    }
}

function displayAlbums(filteredList = albumList) {
    container.innerHTML = ''; 
    filteredList.forEach(album => {
        const card = document.createElement('div');
        card.classList.add('card');
        card.innerHTML = `
            <h3>${album.title}</h3>
            <p>
            <strong>Szerző:</strong> ${album.artist}
            </p>
            <p><strong>Hossz:</strong> ${album.duration}
            </p>
            <p>
            <strong>Zenék száma:</strong> ${album.trackCount}
            </p>
            <button class="edit-button" data-id="${album.id}">Szerkesztés</button>
            <button class="delete-button" data-id="${album.id}">Törlés</button>
        `;
        container.appendChild(card);
    });

    document.querySelectorAll('.edit-button').forEach(button => {
        button.addEventListener('click', editAlbum);
    });
    document.querySelectorAll('.delete-button').forEach(button => {
        button.addEventListener('click', deleteAlbum);
    });
}


function openAddAlbumModal() {
    currentAlbumId = null;
    modalTitle.textContent = 'Új album hozzáadása';
    albumFormElement.reset(); 
    albumModal.classList.remove('hidden');
}

function editAlbum(event) {
    const albumId = event.target.dataset.id;
    const album = albumList.find(item => item.id == albumId);
    if (!album) {
        return;
    }
    currentAlbumId = albumId;
    modalTitle.textContent = 'Album szerkesztése';
    albumFormElement.artist.value = album.artist;
    albumFormElement.title.value = album.title;
    albumFormElement.duration.value = album.duration;
    albumFormElement.trackCount.value = album.trackCount;
    albumModal.classList.remove('hidden');
}

async function deleteAlbum(event) {
    const albumId = event.target.dataset.id;
    try {
        const response = await fetch(`${apiEndpoint}/album/${albumId}`, { method: 'DELETE' });
        if (!response.ok) throw new Error('Failed to delete album');
        loadAlbums(); 
    } catch (error) {
        console.error('Error deleting album:', error);
    }
}

function filterAlbums(event) {
    const searchQuery = event.target.value.toLowerCase();
    const filteredList = albumList.filter(album => album.title.toLowerCase().includes(searchQuery));
    displayAlbums(filteredList);
}

albumFormElement.addEventListener('submit', async (event) => {
    event.preventDefault();
    const albumData = {
        artist: albumFormElement.artist.value,
        title: albumFormElement.title.value,
        duration: albumFormElement.duration.value,
        trackCount: albumFormElement.trackCount.value
    };

    try {
        if (currentAlbumId) {
            const response = await fetch(`${apiEndpoint}/album/${currentAlbumId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(albumData)
            });
            if (!response.ok) throw new Error('Failed to update album');
        } else {
            const response = await fetch(`${apiEndpoint}/album`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(albumData)
            });
            if (!response.ok) throw new Error('Failed to add new album');
        }

        albumModal.classList.add('hidden');
        loadAlbums(); 
    } catch (error) {
        console.error('Error saving album:', error);
    }
});

closeModalBtn.addEventListener('click', () => {
    albumModal.classList.add('hidden');
});

newAlbumBtn.addEventListener('click', openAddAlbumModal);

loadAlbums();

searchInput.addEventListener('input', filterAlbums);
