import sqlite from 'sqlite3';

const db = new sqlite.Database('./Data/database.sqlite');

export function dbAll(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) reject(err);

      else resolve(rows);
    });
  });
}

export function dbGet(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if (err) reject(err);

      else resolve(row);
    });
  });
}

export function dbRun(sql, params = []) {
    return new Promise((resolve, reject) => {
        db.run(sql, params, function(err) {
            if (err) reject(err);

            else resolve(this);
        });
    });
}

export async function initializeDatabase() {
    await dbRun('DROP TABLE IF EXISTS album');
    await dbRun('CREATE TABLE IF NOT EXISTS album (id INTEGER PRIMARY KEY AUTOINCREMENT, artist STRING, title STRING, duration STRING, trackCount INTEGER)');
    const albums = [
        {
            artist: "Pink Floyd",
            title: "The Dark Side of the Moon",
            duration: "42:49",
            trackCount: 10
        },
        {
            artist: "The Beatles",
            title: "Abbey Road",
            duration: "47:03",
            trackCount: 17
        },
        {
            artist: "Led Zeppelin",
            title: "Led Zeppelin IV",
            duration: "42:38",
            trackCount: 8
        },
        {
            artist: "Nirvana",
            title: "Nevermind",
            duration: "49:09",
            trackCount: 13
        },
        {
            artist: "Michael Jackson",
            title: "Thriller",
            duration: "42:19",
            trackCount: 9
        }
    ];

    for (const album of albums) {
        await dbRun('INSERT INTO album (artist, title, duration, trackCount) VALUES (?, ?, ?, ?)', [
          album.artist,
          album.title,
          album.duration,
          album.trackCount
        ]);
    }
}