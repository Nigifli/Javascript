import express from 'express';
import cors from 'cors';
import { dbAll, initializeDatabase, dbGet, dbRun } from './Util/database.js';

const app = express();
app.use(express.json());
app.use(cors());

app.use((err, req, res, next) => {
    if(err)
        res.status(500).json({message: `Error: ${err.message}`});
});

app.get('/albums', async (req, res) => {
    const albums = await dbAll('SELECT * FROM album');
    res.status(200).json(albums);
});

app.get('/albums/:id', async (req, res) => {
    const id = req.params.id;
    const album = await dbGet('SELECT * FROM album WHERE id = ?', [id]);
    if (!album)
        return res.status(404).json({ message: 'Album not found' });

    res.status(200).json(album);
})

app.post('/album', async (req, res) => {
    const album = req.body;
    if(!album.artist || !album.title || !album.duration, !album.trackCount)
        return res.status(400).json({message: 'Artist, title, duration and track count are required'});
    const result = await dbRun('INSERT INTO album (artist, title, duration, trackCount) VALUES (?, ?, ?, ?)', [album.artist, album.title, album.duration, album.trackCount]);
    return res.status(201).json({ id: result.lastID, ...album });
});

app.put('/album/:id', async (req, res) => {
    const id = req.params.id;
    const selectedAlbum = await dbGet('SELECT * FROM album WHERE id = ?', [id]);
    if (!selectedAlbum) 
        return res.status(404).json({ message: 'Class not found' });

    const {artist, title, duration, trackCount} = req.body;
    if (!artist || !title || !duration || !trackCount)
        return res.status(400).json({message: 'Artist, title, duration and track count are required'});

    await dbRun('UPDATE album SET artist = ?, title = ?, duration = ?, trackCount = ? WHERE id = ?', [artist, title, duration, trackCount, id]);
    const updatedAlbum = { id: +id, artist, title, duration, trackCount };
    res.status(200).json(updatedAlbum);
});

app.delete('/album/:id', async (req, res) => {
    const id = req.params.id;
    const album = await dbGet('SELECT * FROM album WHERE id = ?', [id]);
    if(!album)
        return res.status(404).json({message: 'Album not found'});
    await dbRun('DELETE FROM album WHERE id = ?', [id]);
    res.status(200).json({message: 'Album deleted'});
});

async function startServer() {
    await initializeDatabase();
    app.listen(3000, ()=>
        {
            console.log('Server is running on port 3000');
        })
}

await startServer();