import sqlite from 'sqlite3';

const db = new sqlite.Database('./Data/database.sqlite');

export function dbAll(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) reject(err);

      else resolve(rows);
    });
  });
}

export function dbGet(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if (err) reject(err);

      else resolve(row);
    });
  });
}

export function dbRun(sql, params = []) {
    return new Promise((resolve, reject) => {
        db.run(sql, params, function(err) {
            if (err) reject(err);

            else resolve(this);
        });
    });
}

export async function initializeDatabase() {
    await dbRun('DROP TABLE IF EXISTS album');
    await dbRun('CREATE TABLE IF NOT EXISTS album (id INTEGER PRIMARY KEY AUTOINCREMENT, artist STRING, title STRING, duration STRING, trackCount INTEGER)');
    const albums = [
        {
            artist: "Ringo Starr",
            title: "Look Up",
            duration: "26:10",
            trackCount: 8
        },
        {
            artist: "Ela Minus",
            title: "Dia",
            duration: "37:58",
            trackCount: 11
        }
    ];

    for (const album of albums) {
        await dbRun('INSERT INTO album (artist, title, duration, trackCount) VALUES (?, ?, ?, ?)', [
          album.artist,
          album.title,
          album.duration,
          album.trackCount
        ]);
    }
}