const movies = [
    {title: "7th Heaven", year: 1927, director: "Frank Borzage", oscaraward: true},
    {title: "Hallelujah", year: 1929, director: "King Vidor", oscaraward: true},
    {title: "Morocco", year: 1931, director: "Josef von Sternberg", oscaraward: false}
]

export default movies