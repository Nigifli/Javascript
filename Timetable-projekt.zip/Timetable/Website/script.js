const apiUrl = 'http://localhost:3000/timetable';
const timetableTable = document.getElementById('timetable-table').getElementsByTagName('tbody')[0];

async function loadTimetable() {
  const response = await fetch(apiUrl);
  const timetable = await response.json();

  timetableTable.innerHTML = '';

  const days = ['Hétfő', 'Kedd', 'Szerda', 'Csütörtök', 'Péntek']; // Ensure all days are included
  const maxPeriod = 8;
  const times = Array.from({ length: maxPeriod }, (_, i) => i + 1);

  const timetableMap = {};
  timetable.forEach(item => {
    if (!timetableMap[item.day]) {
      timetableMap[item.day] = {};
    }
    timetableMap[item.day][Number(item.period)] = item.subject;
  });

  days.forEach(day => {
    const row = timetableTable.insertRow();
    const dayCell = row.insertCell();
    dayCell.textContent = day;

    let rowHasContent = false; // Track if the row has any content

    times.forEach(period => {
      const cell = row.insertCell();
      const subject = timetableMap[day] && timetableMap[day][period] || ''; // Default to empty string if no class

      // Add a structure even if the cell is empty
      const contentWrapper = document.createElement('div');
      contentWrapper.className = 'cell-content';
      
      if (subject) {
        rowHasContent = true; // Mark that this row has content
        contentWrapper.textContent = subject;

        const buttonGroup = document.createElement('div');
        buttonGroup.className = 'button-group';

        const editButton = document.createElement('button');
        editButton.innerHTML = '✏️';
        editButton.title = 'Szerkesztés';
        editButton.addEventListener('click', async (event) => {
          event.stopPropagation();
          const newSubject = prompt(`Edit class subject for ${day} period ${period}:`, subject);
          if (newSubject && newSubject.trim()) {
            try {
              const response = await fetch(apiUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ day, period, subject: newSubject.trim() })
              });
              if (response.ok) loadTimetable();
              else alert('Failed to update class.');
            } catch (error) {
              alert('Error updating class.');
              console.error(error);
            }
          }
        });

        const deleteButton = document.createElement('button');
        deleteButton.innerHTML = '❌';
        deleteButton.title = 'Törlés';
        deleteButton.addEventListener('click', async (event) => {
          event.stopPropagation();
          if (confirm(`Delete class ${subject} on ${day} period ${period}?`)) {
            try {
              const deleteResponse = await fetch(apiUrl, {
                method: 'DELETE',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ day, period })
              });
              if (deleteResponse.ok) loadTimetable();
              else alert('Failed to delete class.');
            } catch (error) {
              alert('Error deleting class.');
              console.error(error);
            }
          }
        });

        buttonGroup.appendChild(editButton);
        buttonGroup.appendChild(deleteButton);
        contentWrapper.appendChild(buttonGroup);
      } else {
        contentWrapper.textContent = ''; // Empty content for empty cells

        const createButton = document.createElement('button');
        createButton.innerHTML = '➕';
        createButton.title = 'Új óra';
        createButton.addEventListener('click', async (event) => {
          event.stopPropagation();
          const newSubject = prompt(`Enter class subject for ${day} period ${period}:`);
          if (newSubject && newSubject.trim()) {
            try {
              const response = await fetch(apiUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ day, period, subject: newSubject.trim() })
              });
              if (response.ok) loadTimetable();
              else alert('Failed to add class.');
            } catch (error) {
              alert('Error adding class.');
              console.error(error);
            }
          }
        });
        contentWrapper.appendChild(createButton);
      }

      cell.appendChild(contentWrapper);
    });

    row.style.visibility = 'visible'; 
  });
}

loadTimetable();
