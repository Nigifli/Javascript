const timetable = {
    "Hétfő": {
      3: "Matematika"
    },
    "Kedd": {
      1: "Fizika",
      2: "Biológia",
    },
    "Szerda": {
      1: "Történelem",
      4: "Informatika"
    },
    "Csütörtök": {
      1: "Tesi",
      2: "Kémia",
      5: "Földrajz"
    },
    "Péntek": {
      1: "Matematika",
      3: "Angol nyelv"
    }
}

export default timetable;